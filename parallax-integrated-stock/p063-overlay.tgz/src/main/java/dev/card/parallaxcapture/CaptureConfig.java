package dev.card.parallaxcapture;

import net.fabricmc.loader.api.FabricLoader;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class CaptureConfig {
    public String beautyShader = "@current";
    public String depthShader = BundledAssets.DEPTH_SHADER;
    public boolean surfaceCaptureEnabled = true;
    public String surfaceShader = BundledAssets.SURFACE_SHADER;
    public String surfaceCoordinateSpace = "camera_relative_xyz_from_log_viewz24";
    public String surfaceEncoding = "rgb24_log_viewz";
    public double surfaceLogMaxBlocks = 65536.0;
    public double surfaceRangeBlocks = 512.0;
    public int captureWidth = 2560;
    public int captureHeight = 1440;
    public double offsetStepBlocks = 0.5;
    public int gridRadius = 1;

    // All capture waits are explicit and user-configurable in the Durations tab.
    public long shaderReadyMinimumMs = 0;
    public long beautyShaderSwitchSettleMs = 1500;
    public long vanillaShaderSwitchSettleMs = 0;
    public long depthShaderSwitchSettleMs = 300;
    public long surfaceShaderSwitchSettleMs = 300;

    public long beautyPreF2HighResMs = 3000;
    public long beautyPostF2SettleMs = 1000;
    public long vanillaPreCaptureMs = 0;
    public long vanillaPostCaptureMs = 0;
    public long depthPreF2HighResMs = 0;
    public long depthPostF2SettleMs = 500;
    public long surfacePreF2HighResMs = 0;
    public long surfacePostF2SettleMs = 200;
    public long interViewDelayMs = 0;

    public int finalCaptureRenderFrames = 1;
    public boolean warmupF2 = false;
    public boolean keepWarmupImages = false;
    public boolean restoreOriginalShader = true;
    public boolean autoConvert = true;
    public boolean deleteRawAfterSuccess = true;
    public int conversionJpegQuality = 85;
    public int conversionZstdLevel = 9;

    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("parallax-capture.properties");

    public static CaptureConfig defaults() { return new CaptureConfig(); }

    public CaptureConfig copy() {
        CaptureConfig c = new CaptureConfig();
        c.beautyShader = beautyShader;
        c.depthShader = depthShader;
        c.surfaceCaptureEnabled = surfaceCaptureEnabled;
        c.surfaceShader = surfaceShader;
        c.surfaceCoordinateSpace = surfaceCoordinateSpace;
        c.surfaceEncoding = surfaceEncoding;
        c.surfaceLogMaxBlocks = surfaceLogMaxBlocks;
        c.surfaceRangeBlocks = surfaceRangeBlocks;
        c.captureWidth = captureWidth;
        c.captureHeight = captureHeight;
        c.offsetStepBlocks = offsetStepBlocks;
        c.gridRadius = gridRadius;
        c.shaderReadyMinimumMs = shaderReadyMinimumMs;
        c.beautyShaderSwitchSettleMs = beautyShaderSwitchSettleMs;
        c.vanillaShaderSwitchSettleMs = vanillaShaderSwitchSettleMs;
        c.depthShaderSwitchSettleMs = depthShaderSwitchSettleMs;
        c.surfaceShaderSwitchSettleMs = surfaceShaderSwitchSettleMs;
        c.beautyPreF2HighResMs = beautyPreF2HighResMs;
        c.beautyPostF2SettleMs = beautyPostF2SettleMs;
        c.vanillaPreCaptureMs = vanillaPreCaptureMs;
        c.vanillaPostCaptureMs = vanillaPostCaptureMs;
        c.depthPreF2HighResMs = depthPreF2HighResMs;
        c.depthPostF2SettleMs = depthPostF2SettleMs;
        c.surfacePreF2HighResMs = surfacePreF2HighResMs;
        c.surfacePostF2SettleMs = surfacePostF2SettleMs;
        c.interViewDelayMs = interViewDelayMs;
        c.finalCaptureRenderFrames = finalCaptureRenderFrames;
        c.warmupF2 = warmupF2;
        c.keepWarmupImages = keepWarmupImages;
        c.restoreOriginalShader = restoreOriginalShader;
        c.autoConvert = autoConvert;
        c.deleteRawAfterSuccess = deleteRawAfterSuccess;
        c.conversionJpegQuality = conversionJpegQuality;
        c.conversionZstdLevel = conversionZstdLevel;
        return c;
    }

    public void clamp() {
        captureWidth = clamp(captureWidth, 320, 16384);
        captureHeight = clamp(captureHeight, 180, 16384);
        offsetStepBlocks = clamp(offsetStepBlocks, 0.0, 32.0);
        gridRadius = clamp(gridRadius, 0, 5);
        surfaceRangeBlocks = clamp(surfaceRangeBlocks, 1.0, 8192.0);
        surfaceLogMaxBlocks = clamp(surfaceLogMaxBlocks, 1024.0, 1048576.0);

        shaderReadyMinimumMs = clamp(shaderReadyMinimumMs, 0, 60000);
        beautyShaderSwitchSettleMs = clamp(beautyShaderSwitchSettleMs, 0, 60000);
        vanillaShaderSwitchSettleMs = clamp(vanillaShaderSwitchSettleMs, 0, 60000);
        depthShaderSwitchSettleMs = clamp(depthShaderSwitchSettleMs, 0, 60000);
        surfaceShaderSwitchSettleMs = clamp(surfaceShaderSwitchSettleMs, 0, 60000);
        beautyPreF2HighResMs = clamp(beautyPreF2HighResMs, 0, 60000);
        beautyPostF2SettleMs = clamp(beautyPostF2SettleMs, 0, 60000);
        vanillaPreCaptureMs = clamp(vanillaPreCaptureMs, 0, 60000);
        vanillaPostCaptureMs = clamp(vanillaPostCaptureMs, 0, 60000);
        depthPreF2HighResMs = clamp(depthPreF2HighResMs, 0, 60000);
        depthPostF2SettleMs = clamp(depthPostF2SettleMs, 0, 60000);
        surfacePreF2HighResMs = clamp(surfacePreF2HighResMs, 0, 60000);
        surfacePostF2SettleMs = clamp(surfacePostF2SettleMs, 0, 60000);
        interViewDelayMs = clamp(interViewDelayMs, 0, 60000);

        finalCaptureRenderFrames = clamp(finalCaptureRenderFrames, 1, 30);
        conversionJpegQuality = clamp(conversionJpegQuality, 1, 100);
        conversionZstdLevel = clamp(conversionZstdLevel, 1, 22);
        beautyShader = beautyShader == null || beautyShader.isBlank() ? "@current" : beautyShader.trim();
        depthShader = BundledAssets.DEPTH_SHADER;
        surfaceShader = BundledAssets.SURFACE_SHADER;
        surfaceCoordinateSpace = (surfaceCoordinateSpace == null || surfaceCoordinateSpace.isBlank()) ? "camera_relative_xyz_from_log_viewz24" : surfaceCoordinateSpace.trim();
        surfaceEncoding = (surfaceEncoding == null || surfaceEncoding.isBlank()) ? "rgb24_log_viewz" : surfaceEncoding.trim();
    }

    public static CaptureConfig load() {
        CaptureConfig c = new CaptureConfig();
        Properties p = new Properties();
        if (Files.exists(PATH)) {
            try (BufferedReader r = Files.newBufferedReader(PATH)) { p.load(r); }
            catch (IOException e) { ParallaxCaptureClient.LOGGER.warn("Could not read {}", PATH, e); }
        }

        c.beautyShader = p.getProperty("beauty_shader", c.beautyShader).trim();
        c.depthShader = BundledAssets.DEPTH_SHADER;
        c.surfaceCaptureEnabled = parseBoolean(p, "surface_capture_enabled", c.surfaceCaptureEnabled);
        c.surfaceShader = BundledAssets.SURFACE_SHADER;
        c.surfaceCoordinateSpace = p.getProperty("surface_coordinate_space", c.surfaceCoordinateSpace).trim();
        c.surfaceEncoding = p.getProperty("surface_encoding", c.surfaceEncoding).trim();
        c.surfaceLogMaxBlocks = parseDouble(p, "surface_log_max_blocks", c.surfaceLogMaxBlocks, 1024.0, 1048576.0);
        c.surfaceRangeBlocks = parseDouble(p, "surface_range_blocks", c.surfaceRangeBlocks, 1.0, 8192.0);
        c.captureWidth = parseInt(p, "capture_width", c.captureWidth, 320, 16384);
        c.captureHeight = parseInt(p, "capture_height", c.captureHeight, 180, 16384);
        c.offsetStepBlocks = parseDouble(p, "offset_step_blocks", c.offsetStepBlocks, 0.0, 32.0);
        c.gridRadius = 1;

        c.shaderReadyMinimumMs = parseLong(p, "shader_ready_minimum_ms", c.shaderReadyMinimumMs, 0, 60000);
        c.beautyShaderSwitchSettleMs = parseLong(p, "beauty_shader_switch_settle_ms", c.beautyShaderSwitchSettleMs, 0, 60000);
        c.vanillaShaderSwitchSettleMs = parseLong(p, "vanilla_shader_switch_settle_ms", c.vanillaShaderSwitchSettleMs, 0, 60000);
        c.depthShaderSwitchSettleMs = parseLong(p, "depth_shader_switch_settle_ms", c.depthShaderSwitchSettleMs, 0, 60000);
        c.surfaceShaderSwitchSettleMs = parseLong(p, "surface_shader_switch_settle_ms", c.surfaceShaderSwitchSettleMs, 0, 60000);
        c.beautyPreF2HighResMs = parseLong(p, "beauty_pre_f2_highres_ms", c.beautyPreF2HighResMs, 0, 60000);
        c.beautyPostF2SettleMs = parseLong(p, "beauty_post_f2_ms", c.beautyPostF2SettleMs, 0, 60000);
        c.vanillaPreCaptureMs = parseLong(p, "vanilla_pre_capture_ms", c.vanillaPreCaptureMs, 0, 60000);
        c.vanillaPostCaptureMs = parseLong(p, "vanilla_post_capture_ms", c.vanillaPostCaptureMs, 0, 60000);
        c.depthPreF2HighResMs = parseLong(p, "depth_pre_f2_highres_ms", c.depthPreF2HighResMs, 0, 60000);
        c.depthPostF2SettleMs = parseLong(p, "depth_post_f2_ms", c.depthPostF2SettleMs, 0, 60000);
        c.surfacePreF2HighResMs = parseLong(p, "surface_pre_f2_highres_ms", c.surfacePreF2HighResMs, 0, 60000);
        c.surfacePostF2SettleMs = parseLong(p, "surface_post_f2_ms", c.surfacePostF2SettleMs, 0, 60000);
        c.interViewDelayMs = parseLong(p, "inter_view_delay_ms", c.interViewDelayMs, 0, 60000);

        c.finalCaptureRenderFrames = parseInt(p, "final_capture_render_frames", c.finalCaptureRenderFrames, 1, 30);
        c.warmupF2 = parseBoolean(p, "warmup_f2", false); // new fast default; old configs may override explicitly
        c.keepWarmupImages = parseBoolean(p, "keep_f2_images", c.keepWarmupImages);
        c.restoreOriginalShader = parseBoolean(p, "restore_original_shader", c.restoreOriginalShader);
        c.autoConvert = parseBoolean(p, "auto_convert", c.autoConvert);
        c.deleteRawAfterSuccess = parseBoolean(p, "delete_raw_after_success", c.deleteRawAfterSuccess);
        c.conversionJpegQuality = parseInt(p, "conversion_jpeg_quality", 85, 1, 100);
        c.conversionZstdLevel = parseInt(p, "conversion_zstd_level", 9, 1, 22);
        c.clamp();
        c.save();
        return c;
    }

    public void save() {
        clamp();
        Properties p = new Properties();
        p.setProperty("beauty_shader", beautyShader);
        p.setProperty("depth_shader", depthShader);
        p.setProperty("surface_capture_enabled", Boolean.toString(surfaceCaptureEnabled));
        p.setProperty("surface_shader", surfaceShader);
        p.setProperty("surface_coordinate_space", surfaceCoordinateSpace);
        p.setProperty("surface_encoding", surfaceEncoding);
        p.setProperty("surface_log_max_blocks", Double.toString(surfaceLogMaxBlocks));
        p.setProperty("surface_range_blocks", Double.toString(surfaceRangeBlocks));
        p.setProperty("capture_width", Integer.toString(captureWidth));
        p.setProperty("capture_height", Integer.toString(captureHeight));
        p.setProperty("offset_step_blocks", Double.toString(offsetStepBlocks));
        p.setProperty("grid_radius", "1");

        p.setProperty("shader_ready_minimum_ms", Long.toString(shaderReadyMinimumMs));
        p.setProperty("beauty_shader_switch_settle_ms", Long.toString(beautyShaderSwitchSettleMs));
        p.setProperty("vanilla_shader_switch_settle_ms", Long.toString(vanillaShaderSwitchSettleMs));
        p.setProperty("depth_shader_switch_settle_ms", Long.toString(depthShaderSwitchSettleMs));
        p.setProperty("surface_shader_switch_settle_ms", Long.toString(surfaceShaderSwitchSettleMs));
        p.setProperty("beauty_pre_f2_highres_ms", Long.toString(beautyPreF2HighResMs));
        p.setProperty("beauty_post_f2_ms", Long.toString(beautyPostF2SettleMs));
        p.setProperty("vanilla_pre_capture_ms", Long.toString(vanillaPreCaptureMs));
        p.setProperty("vanilla_post_capture_ms", Long.toString(vanillaPostCaptureMs));
        p.setProperty("depth_pre_f2_highres_ms", Long.toString(depthPreF2HighResMs));
        p.setProperty("depth_post_f2_ms", Long.toString(depthPostF2SettleMs));
        p.setProperty("surface_pre_f2_highres_ms", Long.toString(surfacePreF2HighResMs));
        p.setProperty("surface_post_f2_ms", Long.toString(surfacePostF2SettleMs));
        p.setProperty("inter_view_delay_ms", Long.toString(interViewDelayMs));

        p.setProperty("final_capture_render_frames", Integer.toString(finalCaptureRenderFrames));
        p.setProperty("warmup_f2", Boolean.toString(warmupF2));
        p.setProperty("keep_f2_images", Boolean.toString(keepWarmupImages));
        p.setProperty("restore_original_shader", Boolean.toString(restoreOriginalShader));
        p.setProperty("auto_convert", Boolean.toString(autoConvert));
        p.setProperty("delete_raw_after_success", Boolean.toString(deleteRawAfterSuccess));
        p.setProperty("conversion_jpeg_quality", Integer.toString(conversionJpegQuality));
        p.setProperty("conversion_zstd_level", Integer.toString(conversionZstdLevel));

        try {
            Files.createDirectories(PATH.getParent());
            try (BufferedWriter w = Files.newBufferedWriter(PATH)) {
                p.store(w, "Parallax Capture v0.6.3 settings - F7 or Mod Menu");
            }
        } catch (IOException e) {
            ParallaxCaptureClient.LOGGER.warn("Could not save {}", PATH, e);
        }
    }

    private static int parseInt(Properties p, String k, int d, int min, int max) {
        try { return clamp(Integer.parseInt(p.getProperty(k, Integer.toString(d)).trim()), min, max); }
        catch (Exception ignored) { return d; }
    }
    private static long parseLong(Properties p, String k, long d, long min, long max) {
        try { return clamp(Long.parseLong(p.getProperty(k, Long.toString(d)).trim()), min, max); }
        catch (Exception ignored) { return d; }
    }
    private static double parseDouble(Properties p, String k, double d, double min, double max) {
        try { return clamp(Double.parseDouble(p.getProperty(k, Double.toString(d)).trim()), min, max); }
        catch (Exception ignored) { return d; }
    }
    private static boolean parseBoolean(Properties p, String k, boolean d) {
        String v = p.getProperty(k); return v == null ? d : Boolean.parseBoolean(v.trim());
    }
    private static int clamp(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }
    private static long clamp(long v, long min, long max) { return Math.max(min, Math.min(max, v)); }
    private static double clamp(double v, double min, double max) { return Math.max(min, Math.min(max, v)); }
}
