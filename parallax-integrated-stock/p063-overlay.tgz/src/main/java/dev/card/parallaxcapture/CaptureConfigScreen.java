package dev.card.parallaxcapture;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

public final class CaptureConfigScreen extends Screen {
    private enum Tab { PROCESSING, DURATIONS, CAPTURE }
    private record Label(String text, int x, int y, int color) {}

    private final Screen parent;
    private CaptureConfig draft;
    private Tab tab = Tab.PROCESSING;
    private final List<Label> labels = new ArrayList<>();
    private int panelX, panelY, panelW, panelH;

    public CaptureConfigScreen(Screen parent) {
        super(Text.literal("Parallax Capture Settings"));
        this.parent = parent;
        this.draft = ParallaxCaptureClient.getConfig().copy();
    }

    @Override
    protected void init() {
        labels.clear();
        panelW = Math.min(680, Math.max(300, width - 24));
        panelH = Math.min(520, Math.max(300, height - 32));
        panelX = (width - panelW) / 2;
        panelY = Math.max(12, (height - panelH) / 2);

        int tx = panelX + 14;
        int ty = panelY + 42;
        int tabGap = 6;
        int tabW = (panelW - 28 - tabGap * 2) / 3;
        addDrawableChild(ButtonWidget.builder(Text.literal("Processing"), b -> switchTab(Tab.PROCESSING))
                .dimensions(tx, ty, tabW, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Durations"), b -> switchTab(Tab.DURATIONS))
                .dimensions(tx + tabW + tabGap, ty, tabW, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Capture"), b -> switchTab(Tab.CAPTURE))
                .dimensions(tx + (tabW + tabGap) * 2, ty, tabW, 20).build());

        int contentY = ty + 34;
        switch (tab) {
            case PROCESSING -> buildProcessing(contentY);
            case DURATIONS -> buildDurations(contentY);
            case CAPTURE -> buildCapture(contentY);
        }

        int bottomY = panelY + panelH - 32;
        int half = (panelW - 34) / 2;
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> applyAndClose())
                .dimensions(panelX + 14, bottomY, half, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Reset defaults"), b -> {
            draft = CaptureConfig.defaults();
            clearAndInit();
        }).dimensions(panelX + 20 + half, bottomY, half, 20).build());
    }

    private void buildProcessing(int y) {
        int x = panelX + 18;
        int w = panelW - 36;
        addIntField("Beauty JPEG quality", draft.conversionJpegQuality, x, y, w, v -> draft.conversionJpegQuality = v); y += 34;
        addIntField("Requested Zstd level (portable engine max 4)", draft.conversionZstdLevel, x, y, w, v -> draft.conversionZstdLevel = v); y += 34;
        addIntField("Final render frames per shot", draft.finalCaptureRenderFrames, x, y, w, v -> draft.finalCaptureRenderFrames = v); y += 38;

        labels.add(new Label("Global mesh ceiling: 300,000 triangles (hard safety cap)", x, y, 0xAFAFAF)); y += 20;
        addToggle("Auto convert after capture", x, y, w, () -> draft.autoConvert, v -> draft.autoConvert = v); y += 25;
        addToggle("Delete raw capture after successful conversion", x, y, w, () -> draft.deleteRawAfterSuccess, v -> draft.deleteRawAfterSuccess = v); y += 25;
        addToggle("Legacy F2 warmup screenshot", x, y, w, () -> draft.warmupF2, v -> draft.warmupF2 = v); y += 25;
        addToggle("Keep F2 warmup images", x, y, w, () -> draft.keepWarmupImages, v -> draft.keepWarmupImages = v);
    }

    private void buildDurations(int y) {
        int gap = 14;
        int colW = (panelW - 50 - gap) / 2;
        int left = panelX + 18;
        int right = left + colW + gap;
        int yl = y, yr = y;

        addLongField("Shader-ready minimum (ms)", draft.shaderReadyMinimumMs, left, yl, colW, v -> draft.shaderReadyMinimumMs = v); yl += 34;
        addLongField("Beauty shader switch max (ms)", draft.beautyShaderSwitchSettleMs, left, yl, colW, v -> draft.beautyShaderSwitchSettleMs = v); yl += 34;
        addLongField("Beauty pre-capture (ms)", draft.beautyPreF2HighResMs, left, yl, colW, v -> draft.beautyPreF2HighResMs = v); yl += 34;
        addLongField("Beauty post-warmup (ms)", draft.beautyPostF2SettleMs, left, yl, colW, v -> draft.beautyPostF2SettleMs = v); yl += 34;
        addLongField("Vanilla switch max (ms)", draft.vanillaShaderSwitchSettleMs, left, yl, colW, v -> draft.vanillaShaderSwitchSettleMs = v); yl += 34;
        addLongField("Vanilla pre-capture (ms)", draft.vanillaPreCaptureMs, left, yl, colW, v -> draft.vanillaPreCaptureMs = v); yl += 34;
        addLongField("Vanilla post-capture (ms)", draft.vanillaPostCaptureMs, left, yl, colW, v -> draft.vanillaPostCaptureMs = v);

        addLongField("Depth shader switch max (ms)", draft.depthShaderSwitchSettleMs, right, yr, colW, v -> draft.depthShaderSwitchSettleMs = v); yr += 34;
        addLongField("Depth pre-capture (ms)", draft.depthPreF2HighResMs, right, yr, colW, v -> draft.depthPreF2HighResMs = v); yr += 34;
        addLongField("Depth post-warmup (ms)", draft.depthPostF2SettleMs, right, yr, colW, v -> draft.depthPostF2SettleMs = v); yr += 34;
        addLongField("Surface shader switch max (ms)", draft.surfaceShaderSwitchSettleMs, right, yr, colW, v -> draft.surfaceShaderSwitchSettleMs = v); yr += 34;
        addLongField("Surface pre-capture (ms)", draft.surfacePreF2HighResMs, right, yr, colW, v -> draft.surfacePreF2HighResMs = v); yr += 34;
        addLongField("Surface post-warmup (ms)", draft.surfacePostF2SettleMs, right, yr, colW, v -> draft.surfacePostF2SettleMs = v); yr += 34;
        addLongField("Inter-view delay (ms)", draft.interViewDelayMs, right, yr, colW, v -> draft.interViewDelayMs = v);
    }

    private void buildCapture(int y) {
        int x = panelX + 18;
        int w = panelW - 36;
        addIntField("Capture width", draft.captureWidth, x, y, w, v -> draft.captureWidth = v); y += 34;
        addIntField("Capture height", draft.captureHeight, x, y, w, v -> draft.captureHeight = v); y += 34;
        addDoubleField("3×3 camera spacing (blocks)", draft.offsetStepBlocks, x, y, w, v -> draft.offsetStepBlocks = v); y += 34;
        addStringField("Beauty shader (@current recommended)", draft.beautyShader, x, y, w, v -> draft.beautyShader = v); y += 40;
        addToggle("Restore original shader after capture", x, y, w, () -> draft.restoreOriginalShader, v -> draft.restoreOriginalShader = v); y += 30;
        labels.add(new Label("Depth + surface exporters: bundled · grid: fixed 3×3", x, y, 0xAFAFAF)); y += 18;
        labels.add(new Label("F7 opens this screen · F8 starts/cancels capture", x, y, 0xD8D8D8));
    }

    private void switchTab(Tab next) {
        if (tab == next) return;
        tab = next;
        clearAndInit();
    }

    private void addIntField(String label, int value, int x, int y, int w, Consumer<Integer> setter) {
        TextFieldWidget f = addField(label, Integer.toString(value), x, y, w);
        f.setChangedListener(s -> { try { setter.accept(Integer.parseInt(s.trim())); } catch (Exception ignored) {} });
    }
    private void addLongField(String label, long value, int x, int y, int w, Consumer<Long> setter) {
        TextFieldWidget f = addField(label, Long.toString(value), x, y, w);
        f.setChangedListener(s -> { try { setter.accept(Long.parseLong(s.trim())); } catch (Exception ignored) {} });
    }
    private void addDoubleField(String label, double value, int x, int y, int w, Consumer<Double> setter) {
        TextFieldWidget f = addField(label, fmt(value), x, y, w);
        f.setChangedListener(s -> { try { setter.accept(Double.parseDouble(s.trim())); } catch (Exception ignored) {} });
    }
    private void addStringField(String label, String value, int x, int y, int w, Consumer<String> setter) {
        TextFieldWidget f = addField(label, value, x, y, w);
        f.setChangedListener(setter);
    }
    private TextFieldWidget addField(String label, String value, int x, int y, int w) {
        labels.add(new Label(label, x, y, 0xBFBFBF));
        TextFieldWidget f = new TextFieldWidget(textRenderer, x, y + 11, w, 18, Text.literal(label));
        f.setMaxLength(256);
        f.setText(value);
        return addDrawableChild(f);
    }

    private interface BoolGetter { boolean get(); }
    private void addToggle(String name, int x, int y, int w, BoolGetter getter, Consumer<Boolean> setter) {
        ButtonWidget button = ButtonWidget.builder(toggleText(name, getter.get()), b -> {
            boolean nv = !getter.get(); setter.accept(nv); b.setMessage(toggleText(name, nv));
        }).dimensions(x, y, w, 20).build();
        addDrawableChild(button);
    }

    private void applyAndClose() {
        draft.gridRadius = 1;
        draft.depthShader = BundledAssets.DEPTH_SHADER;
        draft.surfaceShader = BundledAssets.SURFACE_SHADER;
        draft.surfaceCaptureEnabled = true;
        draft.clamp();
        ParallaxCaptureClient.applyConfig(draft);
        if (client != null) client.setScreen(parent);
    }

    private static Text toggleText(String name, boolean value) { return Text.literal(name + ": " + (value ? "ON" : "OFF")); }
    private static String fmt(double value) { return String.format(Locale.ROOT, "%.3f", value).replaceAll("0+$", "").replaceAll("\\.$", ""); }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Deliberately no renderBackground(): keep the live world visible behind a translucent HUD-like panel.
        context.fill(panelX, panelY, panelX + panelW, panelY + panelH, 0xB0101010);
        context.fill(panelX, panelY, panelX + panelW, panelY + 2, 0xFFE0E0E0);
        context.drawTextWithShadow(textRenderer, title, panelX + 14, panelY + 13, 0xFFFFFF);
        context.drawTextWithShadow(textRenderer, Text.literal("v0.6.3 · " + tab.name().toLowerCase(Locale.ROOT)), panelX + 14, panelY + 27, 0xAFAFAF);
        for (Label l : labels) context.drawTextWithShadow(textRenderer, Text.literal(l.text()), l.x(), l.y(), l.color());
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void close() { if (client != null) client.setScreen(parent); }
}
